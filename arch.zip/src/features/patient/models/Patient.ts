type Patient = {
  id: number;
  name: string;
  dateOfBirth: Date;
};
