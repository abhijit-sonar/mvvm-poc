export const _patients: Patient[] = [
  {
    id: 1,
    name: "Ab",
    dateOfBirth: new Date(),
  },

  {
    id: 2,
    name: "Cd",
    dateOfBirth: new Date(),
  },
  {
    id: 3,
    name: "Ab",
    dateOfBirth: new Date(),
  },

  {
    id: 4,
    name: "Cd",
    dateOfBirth: new Date(),
  },
];